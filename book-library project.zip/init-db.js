const fs = require('fs');
const path = require('path');
const db = require('./db');
const migration = fs.readFileSync(path.join(__dirname, 'migration.sql'), 'utf8');

db.exec(migration);

console.log("✅ Database initialized successfully");