async function fetchBooks() {
  const res = await fetch('/api/books');
  const books = await res.json();
  const list = document.getElementById('book-list');
  list.innerHTML = '';
  books.forEach(book => {
    const li = document.createElement('li');
    li.textContent = `#${book.id} - ${book.title} by ${book.author}`;
    list.appendChild(li);
  });
}

-
async function addBook() {
  const book = {
    title: document.getElementById('title').value,
    author: document.getElementById('author').value,
    isbn: document.getElementById('isbn').value,
    category: document.getElementById('category').value,
    tags: document.getElementById('tags').value,
    description: document.getElementById('description').value,
  };

  await fetch('/api/books', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(book)
  });

  fetchBooks(); 
}

async function borrowBook() {
  const borrow = {
    book_id: document.getElementById('borrow-book-id').value,
    borrower: document.getElementById('borrower').value,
    notes: document.getElementById('notes').value,
  };

  await fetch('/api/borrows', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(borrow)
  });

  fetchBorrows(); 
}


async function fetchBorrows() {
  const res = await fetch('/api/borrows');
  const borrows = await res.json();
  const list = document.getElementById('borrow-list');
  list.innerHTML = '';
  borrows.forEach(borrow => {
    const li = document.createElement('li');
    li.textContent = `${borrow.borrower} borrowed "${borrow.title}" (${borrow.notes || 'No notes'})`;
    list.appendChild(li);
  });
}
window.onload = () => {
  fetchBooks();
  fetchBorrows();
};
