const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const db = require('./db');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// --- API Routes ---

// Get all books
app.get('/api/books', (req, res) => {
  const books = db.prepare('SELECT * FROM books').all();
  res.json(books);
});

// Add a book
app.post('/api/books', (req, res) => {
  const { title, author, isbn, category, tags, description } = req.body;
  const stmt = db.prepare(
    'INSERT INTO books (title, author, isbn, category, tags, description) VALUES (?, ?, ?, ?, ?, ?)'
  );
  const result = stmt.run(title, author, isbn, category, tags, description);
  res.json({ id: result.lastInsertRowid });
});

// Borrow a book
app.post('/api/borrows', (req, res) => {
  const { book_id, borrower, notes } = req.body;
  const stmt = db.prepare(
    'INSERT INTO borrows (book_id, borrower, notes) VALUES (?, ?, ?)'
  );
  const result = stmt.run(book_id, borrower, notes);
  res.json({ id: result.lastInsertRowid });
});

// Borrowing history
app.get('/api/borrows', (req, res) => {
  const rows = db.prepare(`
    SELECT borrows.*, books.title 
    FROM borrows 
    JOIN books ON borrows.book_id = books.id

  `).all();
  res.json(rows);
});

// Start server
const PORT = 3000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));

